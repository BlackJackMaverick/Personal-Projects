package pokemonqualities;

public class Pokemon {
	/*
	 * A pokemon has 6 stats: HP, Atk, SpAtk, Def, SpDef, Speed
	 */
	private static int level=100;
	private String name;
	private int HP;
	private Stat attack;
	private Stat defense;
	private Stat specialAttack;
	private Stat specialDefense;
	private Stat speed;
	private boolean singleElem;	
	private Element elem1;
	private Element elem2;
	private int status; //0=none, 1=paralysis, 2=poison, 3=burn, 4=sleep, 5=frozen
	/*
	 * getters and setters
	 */
	public boolean getSingleElem(){
		return singleElem;
	}
	public void setSingleElem(boolean b){
		singleElem=b;
	}
	public Element getElem1(){
		return elem1;
	}
	public void setElem1(Element e){
		elem1=e;
	}
	public Element getElem2(){
		return elem2;
	}
	public void setElem2(Element e){
		elem2=e;
	}
	public Stat getAttackStat(){
		return attack;
	}
	public void setAttackStat(Stat s){
		attack=s;
	}
	public Stat getDefenseStat(){
		return defense;
	}
	public void setDefenseStat(Stat s){
		defense=s;
	}
	public Stat getSpecialAttackStat(){
		return specialAttack;
	}
	public void setSpecialAttackStat(Stat s){
		specialAttack=s;
	}
	public Stat getSpecialDefenseStat(){
		return specialDefense;
	}
	public void setSpecialDefenseStat(Stat s){
		specialDefense=s;
	}
	public Stat getSpeedStat(){
		return speed;
	}
	public void setSpeedStat(Stat s){
		speed=s;
	}
	public int getHPStat(){
		return HP;
	}
	public void setHPStat(int i){
		HP=i;
	}
	public static int getLevel(){
		return level;
	}
	public String getName(){
		return name;
	}
	public void setName(String s){
		name=s;
	}
	public int getStatus(){
		return status;
	}
	public void setStatus(int i){
		status=i;
	}
	public attack(Pokemon defendingPokemon, Move attackingMove){
		double damage;
		if(attackingMove.getCategory()==1){//physical damaging move
		damage=((((2*level)/5)+2)*attackingMove.getBasePower()*(this.attack.TotalStat()/defendingPokemon.defense.TotalStat())*(1/50))+2;
		damage=damage*STABMultiplier(attackingMove)*ElementMultiplier(attackingMove,defendingPokemon)*BurnMultiplier(attackingMove);
		damage=damage*RandomMultiplier();
	}
	}
	private double STABMultiplier(Move attackingMOve){
		double multiplier;
		if(this.elem1==attackingMOve.getElement()|| this.elem2==attackingMOve.getElement()){
			multiplier=1.5;
		}else{
			multiplier=1;
		}
		return multiplier;
	}
	private double ElementMultiplier(Move attackingMove, Pokemon defendingPokemon){
		double multiplier;
		if(defendingPokemon.singleElem){
			multiplier=Element.getElementMultiplier()[attackingMove.getElement().getElemnum()][defendingPokemon.elem1.getElemnum()];
		}else{
			multiplier=
			Element.getElementMultiplier()[attackingMove.getElement().getElemnum()][defendingPokemon.elem1.getElemnum()]*
			Element.getElementMultiplier()[attackingMove.getElement().getElemnum()][defendingPokemon.elem2.getElemnum()];
		}
		return multiplier;
	}
	private double BurnMultiplier(Move attackingMove){
		double multiplier;
		if(this.status==3 && attackingMove.getCategory()==2)
			multiplier=0.5;
		else multiplier=1;
		return multiplier;
	}
	private double RandomMultiplier(){//generates a randome number between 0.85-1
		
	}
}
