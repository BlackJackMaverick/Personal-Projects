	package pokemonqualities;
	
	public class Stat {
		//instance variables
		private int stat;
		private int boost;
		
		//constructor
		public Stat(int stat, int boost){
			this.stat=stat;
			this.boost=boost;
		}
		
		//getters
		public int getStat(){return this.stat;}
		public int getBoost(){return this.boost;}
		
		//setters
		public void setStat(int stat){this.stat=stat;}
		public void setBoost(int boost){this.boost=boost;}
		
		//method to return total stat using boost and stats
		public double TotalStat(){
			double totalstat=0;
			switch(boost){
			case 1: totalstat = stat*1.5;
			break;
			case 2: totalstat=stat*2;
			break;
			case 3:totalstat=stat*2.5;
			break;
			case 4:totalstat=stat*3;
			break;
			case 5:totalstat=stat*3.5;
			break;
			case 6:totalstat=stat*4;
			break;
			case -1:totalstat=stat*0.67;
			break;
			case -2:totalstat=stat*0.5;
			break;
			case -3:totalstat=stat*0.4;
			break;
			case -4:totalstat=stat*0.33;
			break;
			case -5:totalstat=stat*0.28;
			break;
			case -6:totalstat=stat*0.25;
			break;
			case 0:totalstat=stat;
			break;
			}
			return totalstat;}
		
		//print out method
		public void printout(Stat s){
			 System.out.println("Stat: " + s.stat + " boost: "+s.boost+ 
					" totalstat: " + s.TotalStat() );
		}
	}
