	package pokemonqualities;
	
	public class Move {
		//instance variables
		private int basepower;
		private int accuracy;
		private int category; // 1=physical, 2=special, 3=status
		private Element elem;
		private int powerpoints;
		//false for physical, true for special
		
		//setters
		public void setBasePower(int basepower){
			this.basepower=basepower;
		}
		public void setAccuracy(int accuracy){
			this.accuracy=accuracy;
		}
		public void setCategory(boolean damagespecialty){
			this.category=category;
		}
		public void setElement(Element e){
			elem=e;
		}
		public void setPowerPoints(int p){
			powerpoints=p;
		}
		
		//getters
		public int getAccuracy(){
			return this.accuracy;
		}
		public int getBasePower(){
			return this.basepower;
		}
		public int getCategory(){
			return this.category;
		}
		public Element getElement(){
			return elem;
		}
		public int getPowerPoints(){
			return powerpoints;
		}
	}
