package pokemonqualities;

public class Element {
	/*
	 * every element has an associated number for lookup, in alphabetical order
	 */
	private int elemnum;
	/*
	 * damage multiplier received of pokemon with a single element from another attacking pokemon's move's element
	 */
	private static double[][] ElementMultiplier;
	/*
	 * constructor
	 */
	public Element(int n){
		this.elemnum=n;
		FillSingleElementDamageDealt();
	}
	/*
	 * getters and setters
	 */
	public int getElemnum(){
		return this.elemnum;
	}
	public void setElemnum(int m){
		this.elemnum =m;
	}
	public static double[][] getElementMultiplier(){
		return ElementMultiplier;
	}
	/*
	 * Fill tables
	 */
	public void FillSingleElementDamageDealt(){
		/*
		 * double element damage dealt.
		 */
		ElementMultiplier = new double[18][18];
		ElementMultiplier[0] = new double[]{1,2,1,1,0.5,0.5,0.5,0.5,0.5,2,1,1,1,0.5,2,1,0.5,1};
		ElementMultiplier[1] = new double[]{1,0.5,1,1,0.5,0.5,1,1,2,1,1,1,1,1,2,1,1,1};
		ElementMultiplier[2] = new double[]{1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,0.5,1};
		ElementMultiplier[3] = new double[]{1,1,0.5,0.5,1,1,1,2,1,0.5,0,1,1,1,1,1,1,2};
		ElementMultiplier[4] = new double[]{1,2,2,1,1,2,0.5,1,1,1,1,1,1,0.5,1,1,0.5,1};	
		ElementMultiplier[5] = new double[]{0.5,2,1,1,0.5,1,1,0.5,0,1,1,2,2,0.5,0.5,2,2,1};
		ElementMultiplier[6]= new double[]{2,1,0.5,1,1,1,0.5,1,1,2,1,2,1,1,1,0.5,2,0.5};
		ElementMultiplier[7] = new double[]{2,1,1,0.5,1,2,1,1,1,2,1,1,1,1,1,0.5,0.5,1};
		ElementMultiplier[8] = new double[]{1,0.5,1,1,1,1,1,1,2,1,1,1,0,1,2,1,1,1};
		ElementMultiplier[9] = new double[]{0.5,1,0.5,1,1,1,0.5,0.5,1,0.5,2,1,1,0.5,1,2,0.5,2};
		ElementMultiplier[10] = new double[]{0.5,1,1,2,1,1,2,0,1,0.5,1,1,1,2,1,2,2,1};
		ElementMultiplier[11] = new double[]{1,1,2,1,1,1,0.5,2,1,2,2,0.5,1,1,1,1,0.5,0.5};
		ElementMultiplier[12] = new double[]{1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0.5,0.5,1};
		ElementMultiplier[13] = new double[]{1,1,1,1,2,1,1,1,0.5,2,0.5,1,1,0.5,1,0.5,0,1};
		ElementMultiplier[14]= new double[]{1,0,1,1,1,2,1,1,1,1,1,1,1,2,0.5,1,0.5,1};
		ElementMultiplier[15] = new double[]{2,1,1,1,1,0.5,2,2,1,1,0.5,2,1,1,1,1,0.5,1};
		ElementMultiplier[16] = new double[]{1,1,1,0.5,2,1,0.5,1,1,1,1,2,1,1,1,2,0.5,0.5};
		ElementMultiplier[17] = new double[]{1,1,1,1,1,1,2,1,1,0.5,2,1,1,1,1,2,1,0.5};
	}
	public double getElemMultiplier(Pokemon p){
		if(p.getSingleElem()){
			return ElementMultiplier[p.getElem1.getElemnum]
		}
		else{
			
		}
	}
}
