package pokemonqualities;

public class Ability {

}
