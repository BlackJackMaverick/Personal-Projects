package pokemonqualities;

public class Test {
	public static void main (String[] args){
		/*Stat s = new Stat(400,1);
		//testing getters and totalstat methods
		System.out.println(s.getStat());
		System.out.println(s.getBoost());
		System.out.println(s.TotalStat());
		//testing setters
		s.setBoost(3);s.setStat(300);
		System.out.println(s.getStat());
		System.out.println(s.getBoost());
		System.out.println(s.TotalStat());
		//testing to string method
		s.printout(s);*/
		Element e = new Element();
		for(int i=0;i<e.getDoubleElementDamageDealt().length;i++){
			for(int j=0;j<e.getDoubleElementDamageDealt().length;j++){
				System.out.print(e.getDoubleElementDamageDealt()[i][j] + " ");
			}
			System.out.println();
		}
}
}