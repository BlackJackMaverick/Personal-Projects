package pokemonqualities;

public class Item {

}
